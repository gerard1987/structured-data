<?php
/*
Plugin Name:  Advanza structured data
Plugin URI:   http://www.waydesign.nl/plugins
Description:  Generates a Json file with dynamic based data, from url. retrieves meta data from Yoast and social media from jetpack database
Version:      0.9
Author:       Gerard de way
Author URI:   http://www.waydesign.nl
Text Domain:  wporg
Domain Path:  /languages
*/

// Plugin updater
require 'plugin-update-checker/plugin-update-checker.php';
$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
	'https://advandm297.297.axc.nl/api/advanza-structured-data.json',
	__FILE__,
	'advanza_structured_data_updater'
);

// Plugin registration
// register_activation_hook( __FILE__, array( 'advanza_structured_data', 'install' ) );

// Includes 
// /**
//  * Problem with the backend in wordpress, no problem with the front-end. Look to include in another way.
//  */
// require plugin_dir_path( __FILE__ ) . 'includes/automatic-yoast-meta-data.php';

class strip_site_data
{
    /**
     * Get an array of a csv file of city names 
     * to determine wether its a valid city name
     */
    function check_location(){

        // Set variables for location
        $currentDirectory = getcwd();
        $Loc_url = plugin_dir_url( __FILE__ ) . 'includes/steden.csv';
        // Turn the csv file into a array
        $csv = array_map('str_getcsv', file($Loc_url));
    
        // Remove whitespace's and set case insensitive for check in array
        $new_csv = [];
        foreach ($csv as $item) {
            $new_item = trim(strtolower($item[0]));
            array_push($new_csv, $new_item);
        }

        return $new_csv;
    }

    /**
     * Set values for file locations, 
     * and format the data for use in the Json.
     */
    function strip_url_data(){
        // Set location variables
        $currentPage = $_SERVER['REQUEST_URI'];
        $currentDirectory = getcwd();
        $currentHome = get_home_url();

        // Get the current logo
        $custom_logo_id = get_theme_mod( 'custom_logo' );
        $image = wp_get_attachment_image_src( $custom_logo_id , 'full' );
        $image = $image[0];
        if (!isset($image) || trim($image) === ''){
            $image = '';
            // Image is empty or null. 
        }

        // Strip url of mime type and format for email and site name
        $homeReplaced = str_replace('https://', '', $currentHome);
        $withoutExtension = substr($homeReplaced, 0, strrpos($homeReplaced, ".")); 
        $homeTrimmed = preg_replace("/[\W\-]/", ' ', $withoutExtension);
        $homeFormatted = ucfirst($homeTrimmed);

        // Strip the location name after the slash, and replace slashes for area served
        $preg_result = [];
        preg_match('/-(.*)/', $currentPage, $preg_result);
        $loc_name = str_replace('.php', '', $preg_result[1]);
        $loc_Trimmed = preg_replace("/[\W\-]/", ' ', $loc_name);
        $locFormatted = ucfirst($loc_Trimmed);
        
        // Check wether the location slug of the page, exist in the location csv
        $strip_site_data = new strip_site_data();
        $new_csv = $strip_site_data->check_location();

        if (in_array(trim(strtolower($loc_Trimmed)), $new_csv)) {
            $locFormatted = trim(ucfirst($loc_Trimmed)) . ', ';
        } else {
            $locFormatted = '';
        }
        // Return associated array for multiple function calls
        return array('locFormatted' => $locFormatted,
                     'loc_Trimmed' => $loc_Trimmed,
                     'homeFormatted' => $homeFormatted,
                     'currentHome' => $currentHome,
                     'image' => $image,
                     'homeReplaced' => $homeReplaced,
        );
    }
}// End of class

class advanza_structured_data
{
    // Plugin install
    static function install() {
        // do not generate any output here
    }
    /**
     * Constructor
     */
    public function __construct(){
        add_action('wp_footer', array($this, 'advanza_structured_data'));
    }
    /**
     * Create Json data in the footer, strip url for Json location information.
     * Import Yoast meta data and Jetpack social media data from classes
     */
    function advanza_structured_data(){
        // Build Json file
        $data = '{
            "@context": "http:\/\/schema.org",
            "@type": "Organization",
            "name": "example Offertes",
            "url": "https:\/\/example.com",
            "sameAs": ["https:\/\/www.facebook.com\/example", "https:\/\/twitter.com\/example", "https:\/\/www.linkedin.com\/company\/example-offertes", "https:\/\/plus.google.com\/example"],
            "logo": "https:\/\/example-offertes.com\/wp-content\/uploads\/2018\/03\/example-offertes.svg",
            "description": "Altijd de beste example offertes uit uw omgeving.",
            "address": {
                "@type": "PostalAddress",
                "addressCountry": "Netherlands"
            },
            "areaServed": "",
            "contactPoint": {
                "@type": "ContactPoint",
                "contactType": "Sales",
                "email": "info@example-offertes.com",
                "url": "https:\/\/example-offertes.com"
            }
        }';
    
        // Decode the json data in php readable code
        $jsonString = json_decode($data, true);

        // Get the data out of strip data class
        $strip_site_data = new strip_site_data();
        $stripped_url_data = $strip_site_data->strip_url_data();
        
        // Write the dynamic input from yoast and jetpack to the Json file, and append it to the page
        $jetpack_data_retrieve = new jetpack_data_retrieve();
        // Yoast meta data from .docx
        $automatic_yoast_meta_data = new automatic_yoast_meta_data();
        $yoast_data = $automatic_yoast_meta_data->automatic_yoast_meta_data();
        // Yoast meta data from wordpress
        $yoast_wp_data = $jetpack_data_retrieve->yoast_meta_data_fetch();
        // Check wether there is meta data in wp, if not try to get it out of the .docx
        $description = $yoast_wp_data;
        if (empty($yoast_wp_data)){
            $description = $yoast_data;
        }
        if (is_null($description)) {
            $description = '';
        }

        $jsonString['areaServed'] = $stripped_url_data['locFormatted'] . "Netherlands";
        $jsonString['name'] =  $stripped_url_data['homeFormatted'];
        $jsonString['url'] = $stripped_url_data['currentHome'];
        $jsonString['logo'] = $stripped_url_data['image'];
        $jsonString['description'] = $description;
        $jsonString['sameAs'] = $jetpack_data_retrieve->jetpack_database_fetch();
        $jsonString['contactPoint']['email'] = 'info@' . $stripped_url_data['homeReplaced'];
        $jsonString['contactPoint']['url'] = $stripped_url_data['currentHome'];

        // Re-encode the data
        $newJsonString = json_encode($jsonString, true);

        // Rewrite the data to readable data
        $new_data = '<script type="application/ld+json">' . strval($newJsonString) . '</script>';

        // Write the updated json file to the content and check if it is a page
        if (is_page() || is_singular()) {
            print $new_data;
        }
    }
} // End of class

class jetpack_data_retrieve
{ 
    /**
     * Get Jetpack data from database, and retrieve social media url's
     */
    function jetpack_database_fetch(){
        $social_data = [];
        global $wpdb;
        $results = $wpdb->get_results( "SELECT * FROM `{$wpdb->prefix}options` WHERE option_name = 'jetpack_options'");
        // get object property out of the array
        $get_data = $results[0]->option_value;
        // Deserialize the data from database
        $php_data = unserialize($get_data);
        // Loop thrue the array, and get the url data
        if ($php_data['publicize_connections']['facebook'] != null) {
            foreach($php_data['publicize_connections']['facebook'] as $value) {
                $temp = $value['connection_data']['meta']['link'];
                array_push($social_data, $temp);
            }
        }
        if ($php_data['publicize_connections']['twitter'] != null) {        
            foreach($php_data['publicize_connections']['twitter'] as $value){
                $temp = $value['connection_data']['meta']['link'];
                array_push($social_data, $temp);
            }
        }
        if ($php_data['publicize_connections']['google_plus'] != null){
            foreach($php_data['publicize_connections']['google_plus'] as $value){
                $temp = $value['external_id'];
                $temp = 'https://plus.google.com/' . $temp;
                array_push($social_data, $temp); 
            }
        }

        return $social_data;
    }
    /**
     * Get the Yoast meta data out of wordpress
     */
    function yoast_meta_data_fetch(){
        // Yoast meta description
        $yoast = get_post_meta(get_the_ID(), '_yoast_wpseo_metadesc', true); 
        return $yoast;
    }
} // End of class

class automatic_yoast_meta_data
{
    /**
     * Constructor
     */
    public function __construct(){
        add_action('wp_head', array($this, 'automatic_yoast_meta_data'), 100);
        add_filter('wpseo_metadesc', array($this, 'yoast_add_keywords'), 10, 1);
    }

    /**
     * Convert .docx file's to text
     */
    function readDocx($filePath) {
        // Create new ZIP archive
        $zip = new ZipArchive;
        $dataFile = 'word/document.xml';
        // Open received archive file
        if (true === $zip->open($filePath)) {
            // If done, search for the data file in the archive
            if (($index = $zip->locateName($dataFile)) !== false) {
                // If found, read it to the string
                $data = $zip->getFromIndex($index);
                // Close archive file
                $zip->close();
                // Load XML from a string
                // Skip errors and warnings
                $xml = new DOMDocument();
                $xml->loadXML($data, LIBXML_NOENT | LIBXML_XINCLUDE | LIBXML_NOERROR | LIBXML_NOWARNING);
                // Return data without XML formatting tags
    
                $contents = explode('\n',strip_tags($xml->saveXML()));
                $text = '';
                foreach($contents as $i=>$content) {
                    $text .= $contents[$i];
                }
                return $text;
            }
            $zip->close();
        }
        // In case of failure return empty string
        return "";
    }

    /**
     * Retrieve meta description out of file, and write it to the Yoast meta description
     */
    function automatic_yoast_meta_data(){
        
        // Set variables for file location
        $currentDirectory = getcwd();
        $currentPage = $_SERVER['REQUEST_URI'];
        $currentFolder = '/teksten/meta/metadata.docx';
        $file = $currentDirectory . $currentFolder;

        // Set regex var, for stripping out page name
        $temp_trimmed = preg_replace('/[\/]/', '', $currentPage);
        $page_name_trimmed = preg_replace('/[-]/', ' ', $temp_trimmed);
        $page_name_trimmed = ucwords($page_name_trimmed);

        // Convert the document to text, and to html after that.
        $automatic_yoast_meta_data = new automatic_yoast_meta_data();
        $converted_document = $automatic_yoast_meta_data->readDocx($file);
        
        $html_document = html_entity_decode ($converted_document);
        
        // Retrieve the content and explode the array
        global $final_output;
        $text = explode('[placeholder dynamic text]', $html_document);
        foreach ($text as $item){
            if (!empty($page_name_trimmed) && strpos($item, $page_name_trimmed) !== false){
                $final_output = $item;
            }
        }
        // function Return
        return $final_output;
    }

    // $final = automatic_yoast_meta_data();
    // Write to Yoast meta data
    function yoast_add_keywords( $str ) {
        $automatic_yoast_meta_data = new automatic_yoast_meta_data;
        $final = $automatic_yoast_meta_data->automatic_yoast_meta_data();

        $yoast = get_post_meta(get_the_ID(), '_yoast_wpseo_metadesc', true);
        $newStr = $str;
        if (!empty($yoast)){
            $final = $yoast;
        } else {
            $final = $final;
        }
        $newStr = $final;
        return $newStr;
    }

} // End of class

// Declare instances
$jetpack_data = new jetpack_data_retrieve();
$advanza_structured_data = new advanza_structured_data();


// Report simple running errors
error_reporting(E_ERROR | E_WARNING | E_PARSE);
    // add_action('wp_footer', 'advanza_structured_data', 100);
?>
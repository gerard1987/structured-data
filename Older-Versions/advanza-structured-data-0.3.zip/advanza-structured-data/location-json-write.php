<?php
 /*
Plugin Name:  Advanza structured data
Plugin URI:   http://www.waydesign.nl/plugins
Description:  Generates a Json file with dynamic based data, from url. retrieves meta data from Yoast and social media from jetpack database
Version:      0.3
Author:       Gerard de way
Author URI:   http://www.waydesign.nl
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  wporg
Domain Path:  /languages
*/

// Plugin updater
require 'plugin-update-checker/plugin-update-checker.php';
$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
	'https://advandm297.297.axc.nl/advanza-structured-data.json',
	__FILE__,
	'advanza_structured_data_updater'
);

// Plugin registration
register_activation_hook( __FILE__, 'pluginprefix_advanza_structured_data' );
register_deactivation_hook( __FILE__, 'pluginprefix_advanza_structured_data' );

if (!function_exists('advanza_structured_data')){
    function advanza_structured_data(){
    // Build Json file
    $data = '{
        "@context": "http:\/\/schema.org",
        "@type": "Organization",
        "name": "example Offertes",
        "url": "https:\/\/example.com",
        "sameAs": ["https:\/\/www.facebook.com\/example", "https:\/\/twitter.com\/example", "https:\/\/www.linkedin.com\/company\/example-offertes", "https:\/\/plus.google.com\/example"],
        "logo": "https:\/\/example-offertes.com\/wp-content\/uploads\/2018\/03\/example-offertes.svg",
        "description": "Altijd de beste example offertes uit uw omgeving.",
        "address": {
            "@type": "PostalAddress",
            "addressCountry": "Netherlands"
        },
        "areaServed": "",
        "contactPoint": {
            "@type": "ContactPoint",
            "contactType": "Sales",
            "email": "info@example-offertes.com",
            "url": "https:\/\/example-offertes.com"
        }
    }';

    // Set values and create regex for variables
    $url = 'http://' . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
    $currentPage = $_SERVER['REQUEST_URI'];
    $currentServer = $_SERVER['SERVER_NAME'];
    $currentDirectory = getcwd();
    $currentHome = get_home_url();
    $social_data = [];
    // Get the current logo
    $custom_logo_id = get_theme_mod( 'custom_logo' );
    $image = wp_get_attachment_image_src( $custom_logo_id , 'full' );
    if (!isset($image) || trim($image) === ''){
        $image = '';
        // Image is empty or null. 
    }

    // Regex for stripping name out of url and removing mime type
    $homeReplaced = str_replace('https://', '', $currentHome);
    $withoutExtension = substr($homeReplaced, 0, strrpos($homeReplaced, ".")); // Remove everything after . 
    $homeTrimmed = preg_replace("/[\W\-]/", ' ', $withoutExtension); // Replace all non alpha numeric with space's 
    $homeFormatted = ucfirst($homeTrimmed);

    // Regex check page name for - perform check to replace string before delimeter.
    $string_pos = strpos($currentPage, '-');
    $preg_result = [];
    preg_match('/-(.*)/', $currentPage, $preg_result); // Location name stripped after - and put in preg_result

    // Add delimeters and strip slashes
    $pageString = strval($currentPage) . "/"; 
    $loc = str_replace('/', '', $currentPage);
    $loc_name = str_replace('.php', '', $preg_result[1]);
    $loc_Trimmed = preg_replace("/[\W\-]/", ' ', $loc_name);
    $locFormatted = ucfirst($loc_Trimmed);

    // Get Jetpack data from database
    global $wpdb;
    $results = $wpdb->get_results( "SELECT * FROM `{$wpdb->prefix}options` WHERE option_name = 'jetpack_options'");
    // get object property out of the array
    $get_data = $results[0]->option_value;
    // Deserialize the data from database
    $php_data = unserialize($get_data);

    // Loop thrue the array, and get the url data 
    foreach($php_data['publicize_connections']['facebook'] as $value) {
        $temp = $value['connection_data']['meta']['link'];
        array_push($social_data, $temp);
    }
    foreach($php_data['publicize_connections']['twitter'] as $value){
        $temp = $value['connection_data']['meta']['link'];
        array_push($social_data, $temp);
    }
    foreach($php_data['publicize_connections']['google_plus'] as $value){
        $temp = $value['external_id'];
        $temp = 'https://plus.google.com/' . $temp;
        array_push($social_data, $temp); 
    }

    // Yoast meta description
    $yoast = get_post_meta(get_the_ID(), '_yoast_wpseo_metadesc', true); 

    // Build location data function
    $url = 'http://' . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
    $Loc_url = '/teksten/steden.csv';
    $currentDirectory = getcwd();
    $file = $currentDirectory . $Loc_url;
    $loc_data = file_get_contents($file);

    $csv = array_map('str_getcsv', file($file));
    $new_csv = [];

    foreach ($csv as $item) {
        $new_item = trim(strtolower($item[0]));
        array_push($new_csv, $new_item);
    } 

    // Check wether the location slug of the page, exist in the locatin csv
    if (in_array(trim(strtolower($loc_Trimmed)), $new_csv)) {
        // echo 'Succes!!! ' . $loc_Trimmed;
        $locFormatted = ucfirst($loc_Trimmed) . ', ';
    } else {
        // echo 'Fail ' . $loc_Trimmed;
        $locFormatted = '';
    }

        // Decode the json data in php readable code
        $jsonString = json_decode($data, true);
        
        // Write the dynamic input to the Json file, and append it to the page
        $jsonString['areaServed'] = $locFormatted . "Netherlands"; // Write location name based on url to the Json
        $jsonString['name'] =  $homeFormatted;
        $jsonString['url'] = $currentHome;
        $jsonString['logo'] = $image;
        $jsonString['description'] = $yoast; 
        $jsonString['sameAs'] = $social_data; 
        $jsonString['contactPoint']['email'] = 'info@' . $homeReplaced;
        $jsonString['contactPoint']['url'] = $currentHome;

        // Re-encode the data
        $newJsonString = json_encode($jsonString, true);

        // Rewrite the data to readable data
        $new_data = '<script type="application/ld+json">' . strval($newJsonString) . '</script>';

        // Write the updated json file to the content
         $data = $new_data;
         echo $data;
    }
    // Disable Notice warnings 
    error_reporting(E_ERROR | E_WARNING | E_PARSE);
    add_action('wp_footer', 'advanza_structured_data', 100);
}
?>